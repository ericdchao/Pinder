//
//  Constants.swift
//  Pinder
//
//  Created by Labuser on 4/10/17.
//  Copyright © 2017 Kate Harline. All rights reserved.
//

import Foundation



let isPet = 2
let isUser = 1
let userPassDoesNotExist = 0
